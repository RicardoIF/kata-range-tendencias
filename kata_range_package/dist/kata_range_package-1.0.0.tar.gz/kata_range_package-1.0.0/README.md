# Kata range package

## 1.About

This is a package made to go according with the Kata Range assignment to install it you must meet the following requirements:

- Python 3.7 or newer

This package implements the following methods:

- getAllPoints
- endPoints
- overlapsRange
- equals
